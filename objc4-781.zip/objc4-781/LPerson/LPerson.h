//
//  LPerson.h
//  LPerson
//
//  Created by kevin on 2020/9/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LPerson : NSObject
{
    NSString *hobby;
}
@property (nonatomic, copy) NSString *cjl_name;
- (void)sayHello;
+ (void)sayBye;

@end

NS_ASSUME_NONNULL_END
