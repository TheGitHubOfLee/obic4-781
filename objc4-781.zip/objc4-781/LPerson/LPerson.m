//
//  LPerson.m
//  LPerson
//
//  Created by kevin on 2020/9/8.
//

#import "LPerson.h"
#import <objc/message.h>
#import <malloc/malloc.h>

@implementation LPerson
- (void)sayHello
{}
+ (void)sayBye
{}

@end
