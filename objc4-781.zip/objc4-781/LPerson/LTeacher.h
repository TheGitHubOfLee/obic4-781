//
//  LTeacher.h
//  LPerson
//
//  Created by kevin on 2020/9/14.
//

#import "LPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface LTeacher : LPerson

@end

NS_ASSUME_NONNULL_END
