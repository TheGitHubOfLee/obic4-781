//
//  LTeacher.m
//  LPerson
//
//  Created by kevin on 2020/9/14.
//

#import "LTeacher.h"

@implementation LTeacher

@end
