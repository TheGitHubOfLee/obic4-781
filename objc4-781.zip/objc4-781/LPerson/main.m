//
//  main.m
//  LPerson
//
//  Created by kevin on 2020/9/8.
//

#import <Foundation/Foundation.h>
#import "LPerson.h"
#import "LTeacher.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //ISA_MASK  0x00007ffffffffff8ULL
        LPerson *person = [LPerson alloc];
        LTeacher *teacher = [LTeacher alloc];
        NSLog(@"Hello, World! %@ - %@",person,teacher);
    }
    return 0;
}
