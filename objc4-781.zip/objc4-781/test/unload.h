#include "test.h"

@interface SmallClass : TestRoot @end

@interface BigClass : TestRoot @end

